module.exports = {
    "Success": 200,
    "InternalServerError": 500,
    "NotFound": 404,
    "UnAuthorized":401,
    "BLError":403,
}