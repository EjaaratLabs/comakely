module.exports = {
    secret:"test",
    defaultPass:''
}
