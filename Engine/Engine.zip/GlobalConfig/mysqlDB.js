module.exports = {
  // "0": {
  //   host: 'localhost',
  //   user: 'ejaassac_levis',
  //   password: 'ejaarat',
  //   database: 'ejaassac_levis'
  // },
  "0": {
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'comakely',
  },
}